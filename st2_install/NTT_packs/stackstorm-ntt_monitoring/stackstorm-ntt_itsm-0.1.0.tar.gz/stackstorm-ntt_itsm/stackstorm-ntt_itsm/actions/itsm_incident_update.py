#!/usr/bin/env python
# Copyright 2021 Encore Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from lib.base_action import BaseAction
import datetime as dt 

class ITSMIncidentUpdate(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(ITSMIncidentUpdate, self).__init__(config)

    def servicenow_update(self, close, escalate, inc_id, notes, work_in_progress, pending, pending_mins):
        endpoint = '/api/now/table/incident/' + inc_id

        if work_in_progress:
            payload = {
                'assigned_to': 'Automation Service',
                'incident_state': '-3',
                'state': '-3'
            }
            if notes:
                payload['work_notes'] = notes
        elif close:
            payload = {
                'incident_state': '7',
                'state': '7',
                'close_code': 'Solved Remotely (Permanently)',
                'work_notes':notes
            }
            if notes:
                payload['close_notes'] = notes
            else:
                raise "notes is a required field when closing an incident!"
        elif escalate:
            payload = {
                'assigned_to': '',
                'incident_state': '2',
                'state': '2'
            }
            if notes:
                payload['work_notes'] = notes
        elif pending:
            nowtime = dt.datetime.now() + dt.timedelta(minutes = pending_mins)                                                          
            now_plus_pendingmins = dt.datetime.strftime(nowtime, "%Y-%m-%d %H:%M:%S")         
            payload = {                 
                'incident_state': '-5',
                'u_state_reason': 'Monitoring',
                'u_pending_end_date': now_plus_pendingmins,
                'state': '-5'
            }
            if notes:
                payload['work_notes'] = notes
        elif len(notes) > 0:
            payload = { 
                'work_notes': notes
            }             
        else:
            raise Exception("One of close, escalate, or work_in_progress must be set to True!")

        inc = self.sn_api_call('PATCH', endpoint, payload=payload)

        return inc

    def run(self, close, escalate, inc_id, notes, work_in_progress,pending, pending_mins):
        itsm_tool = self.config['itsm_tool']

        return_value = False
        if itsm_tool == 'servicenow':
            return_value = self.servicenow_update(close, escalate, inc_id, notes, work_in_progress,pending, pending_mins)
        elif itsm_tool == 'helix':
            return_value = True
        else:
            error_message = 'Could not get ITSM info please check the config file and try again'
            return_value = (False, {'error_message': error_message})

        return return_value
