#!/usr/bin/env python
# Copyright 2021 Encore Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from st2reactor.sensor.base import PollingSensor
from st2client.models.keyvalue import KeyValuePair  # pylint: disable=no-name-in-module
import requests
import ast
import socket
import os
from st2client.client import Client
import sys
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + '/../actions/lib')
import base_action

__all__ = [
    'ServiceNowIncidentPendingSensor'
]


class ServiceNowIncidentPendingSensor(PollingSensor):
    def __init__(self, sensor_service, config=None, poll_interval=None):
        super(ServiceNowIncidentPendingSensor, self).__init__(sensor_service=sensor_service,
                                                       config=config,
                                                       poll_interval=poll_interval)
        self._logger = self._sensor_service.get_logger(__name__)
        self.base_action = base_action.BaseAction(config)

    def setup(self):
        self.sn_username = self._config['servicenow']['username']
        self.sn_password = self._config['servicenow']['password']
        self.sn_url = self._config['servicenow']['url']
        self.servicenow_headers = {'Content-type': 'application/json',
                                   'Accept': 'application/json'}
        self.st2_fqdn = socket.getfqdn()
        st2_url = "https://{}/".format(self.st2_fqdn)
        self.st2_client = Client(base_url=st2_url)

    def poll(self):
        # Query for all active and open incidents        
        sn_inc_endpoint = '/api/now/table/incident?sysparm_query=active=true^incident_state=-5^' \
            'assigned_to.name=Automation Service^u_pending_end_date>javascript:gs.minutesAgoStart(15)^u_pending_end_date<javascript:gs.minutesAgoStart(-15)^' \
            'descriptionLIKEmemory%20usage%20on^ORdescriptionLIKEmemory%20used%20on'

        sn_inc_url = "https://{0}{1}".format(self.sn_url,
                                             sn_inc_endpoint)

        sn_result = requests.request('GET',
                                     sn_inc_url,
                                     auth=(self.sn_username, self.sn_password),
                                     headers=self.servicenow_headers)

        sn_result.raise_for_status()
        sn_incidents = sn_result.json()['result']
        self._logger.info('Pending sensor: ' + str(sn_incidents))
        self.check_incidents(sn_incidents)

    def check_incidents(self, sn_incidents):
        ''' Create a trigger to run cleanup on any open incidents that are not being processed
        '''
        inc_st2_key = 'servicenow.Pending_incidents_processing'
        processing_incs = self.st2_client.keys.get_by_name(inc_st2_key)

        processing_incs = [] if processing_incs is None else ast.literal_eval(processing_incs.value)

        for inc in sn_incidents:
            # skip any incidents that are currently being processed
            if inc['number'] in processing_incs:
                self._logger.info('Already processing Pending INC: ' + inc['number'])
                continue
            else:
                self._logger.info('Processing Pending INC: ' + inc['number'])
                processing_incs.append(inc['number'])
                incs_str = str(processing_incs)
                kvp = KeyValuePair(name=inc_st2_key, value=incs_str)
                self.st2_client.keys.update(kvp)
                self.check_description(inc)

    def get_company_and_ag_and_ciname(self, inc):
        if inc['assignment_group'] and inc['assignment_group']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                    url=inc['assignment_group']['link'])
            assign_group = response['name']
        else:
            self._logger.info('Assignment Group not found for INC: ' + inc['number'])
            assign_group = ''

        if inc['company'] and inc['company']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                   url=inc['company']['link'])
            company = response['name']
        else:
            self._logger.info('Company not found for INC: ' + inc['number'])
            company = ''
        
        if inc['cmdb_ci'] and inc['cmdb_ci']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                   url=inc['cmdb_ci']['link'])
            configuration_item_name = response['name']
        else:
            self._logger.info('Company not found for INC: ' + inc['number'])
            configuration_item_name = ''

        return assign_group, company,configuration_item_name

    def check_description(self, inc):
        desc = inc['description'].lower()
        assign_group, company, configuration_item_name = self.get_company_and_ag_and_ciname(inc)
         
        
        if (('memory usage on' in desc or 'memory used on' in desc) and ('intel' in assign_group.lower() or 'wintel' in assign_group.lower())):
            #assign_group, company = self.get_company_and_ag(inc)

            ci_address_begin = desc.split('memory usage on ')[-1]
            ci_address = ci_address_begin.split(' ')[0]
            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None
            
            if 'memory usage on' in desc:
                rec_short_desc = 'memory usage on'
                rec_detailed_desc = 'memory usage on'
            elif 'memory usage on' in desc: 
                rec_short_desc = 'memory used on'
                rec_detailed_desc = 'memory used on'
            
            if 'physical memory' in desc:
                memory_type = 'Physical'
            elif 'virtual' in desc:
                memory_type = 'Virtual'
            elif ('physical' in desc or 'windows | memory usage |' in desc or  'memory utilization' in desc or 'memory usage on' in desc ):
                memory_type = 'Physical'
            elif ('high memory paging' in desc or 'paging is now' in desc):
               memory_type = 'PagesPerSec'
            elif ('paging file usage' in desc):
               memory_type = 'PagingFile'
            elif ('threshold of memory not met' in desc):
               memory_type = 'MemoryAvailableBytes'
            elif ('memory low:' in desc):
               memory_type = 'MemoryUsedBytesPct'
            else:
               memory_type = 'Physical'
               
            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold,
                'incident_state': inc['incident_state'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name,
                'memory_type':memory_type
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.win_memory_high', payload=payload)    

    def cleanup(self):
        pass

    def add_trigger(self, trigger):
        pass

    def update_trigger(self, trigger):
        pass

    def remove_trigger(self, trigger):
        pass
