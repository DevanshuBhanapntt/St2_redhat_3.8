#!/usr/bin/env python
# Copyright 2021 Encore Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from st2reactor.sensor.base import PollingSensor
from st2client.models.keyvalue import KeyValuePair  # pylint: disable=no-name-in-module
import requests
import ast
import socket
import os
from st2client.client import Client
import sys
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + '/../actions/lib')
import base_action

__all__ = [
    'ServiceNowIncidentSensor'
]


class ServiceNowIncidentSensor(PollingSensor):
    def __init__(self, sensor_service, config=None, poll_interval=None):
        super(ServiceNowIncidentSensor, self).__init__(sensor_service=sensor_service,
                                                       config=config,
                                                       poll_interval=poll_interval)
        self._logger = self._sensor_service.get_logger(__name__)
        self.base_action = base_action.BaseAction(config)

    def setup(self):
        self.sn_username = self._config['servicenow']['username']
        self.sn_password = self._config['servicenow']['password']
        self.sn_url = self._config['servicenow']['url']
        self.servicenow_headers = {'Content-type': 'application/json',
                                   'Accept': 'application/json'}
        self.st2_fqdn = socket.getfqdn()
        st2_url = "https://{}/".format(self.st2_fqdn)
        self.st2_client = Client(base_url=st2_url)

    def poll(self):
        # Query for all active and open incidents
        sn_inc_endpoint = '/api/now/table/incident?sysparm_query=active=true^state=2^description' \
            'LIKEnot%20responding%20to%20Ping^ORdescriptionLIKEcpu%20utilization%20on^OR' \
            'descriptionLIKEmemory%20usage%20on^ORdescriptionLIKEmemory%20used%20on^ORdescription' \
            'LIKElogical%20disk%20free%20space%20on'

        sn_inc_url = "https://{0}{1}".format(self.sn_url,
                                             sn_inc_endpoint)

        sn_result = requests.request('GET',
                                     sn_inc_url,
                                     auth=(self.sn_username, self.sn_password),
                                     headers=self.servicenow_headers)

        sn_result.raise_for_status()
        sn_incidents = sn_result.json()['result']
        self.check_incidents(sn_incidents)

    def check_incidents(self, sn_incidents):
        ''' Create a trigger to run cleanup on any open incidents that are not being processed
        '''
        inc_st2_key = 'servicenow.incidents_processing'
        processing_incs = self.st2_client.keys.get_by_name(inc_st2_key)

        processing_incs = [] if processing_incs is None else ast.literal_eval(processing_incs.value)

        for inc in sn_incidents:
            # skip any incidents that are currently being processed
            if inc['number'] in processing_incs:
                self._logger.info('Already processing INC: ' + inc['number'])
                continue
            else:
                self._logger.info('Processing INC: ' + inc['number'])
                processing_incs.append(inc['number'])
                incs_str = str(processing_incs)
                kvp = KeyValuePair(name=inc_st2_key, value=incs_str)
                self.st2_client.keys.update(kvp)
                self.check_description(inc)

    def get_company_and_ag(self, inc):
        if inc['assignment_group'] and inc['assignment_group']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                    url=inc['assignment_group']['link'])
            assign_group = response['name']
        else:
            self._logger.info('Assignment Group not found for INC: ' + inc['number'])
            assign_group = ''

        if inc['company'] and inc['company']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                   url=inc['company']['link'])
            company = response['name']
        else:
            self._logger.info('Company not found for INC: ' + inc['number'])
            company = ''

        return assign_group, company

    def check_description(self, inc):
        desc = inc['description'].lower()

        if 'is not responding to ping' in desc:
            assign_group, company = self.get_company_and_ag(inc)

            if assign_group == '':
                check_uptime = False
                os_type = ''
            else:
                check_uptime = True
                os_type = 'windows' if 'intel' in assign_group.lower() else 'linux'

            ci_address_end = desc.split(' is not responding to ping')[0]
            ci_address = ci_address_end.split(' ')[-1]
            payload = {
                'assignment_group': assign_group,
                'check_uptime': check_uptime,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': os_type,
                'short_desc': inc['short_description']
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.unreachable_ping', payload=payload)
        elif 'cpu utilization on' in desc:
            assign_group, company = self.get_company_and_ag(inc)

            ci_address_begin = desc.split('cpu utilization on ')[-1]
            ci_address = ci_address_begin.split(' ')[0]
            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'cpu_name': '_total',
                'cpu_type': 'ProcessorTotalProcessorTime',
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.high_cpu', payload=payload)
        elif 'memory usage on' in desc or 'memory used on' in desc:
            assign_group, company = self.get_company_and_ag(inc)

            if 'memory usage on' in desc:
                ci_address_begin = desc.split('memory usage on ')[-1]
            else:
                ci_address_begin = desc.split('memory used on ')[-1]
            ci_address = ci_address_begin.split(' ')[0]
            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None
            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'memory_threshold': threshold,
                'os_type': 'linux',
                'short_desc': inc['short_description']
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.high_memory', payload=payload)
        elif 'logical disk free space on' in desc:
            assign_group, company = self.get_company_and_ag(inc)

            ci_address_begin = desc.split('logical disk free space on ')[-1]
            ci_address = ci_address_begin.split(' ')[0]
            disk_name_end = inc['description'].split(':')[0]
            disk_name = disk_name_end.split(' ')[-1]
            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None
            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'disk_name': disk_name,
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.high_disk', payload=payload)

    def cleanup(self):
        pass

    def add_trigger(self, trigger):
        pass

    def update_trigger(self, trigger):
        pass

    def remove_trigger(self, trigger):
        pass
