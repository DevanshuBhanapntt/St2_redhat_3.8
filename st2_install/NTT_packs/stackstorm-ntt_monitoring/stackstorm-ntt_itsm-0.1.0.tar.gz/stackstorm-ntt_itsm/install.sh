#!/usr/bin/env bash

st2 pack remove ntt_itsm
cp -r stackstorm-ntt_itsm /opt/stackstorm/packs/ntt_itsm
cp -r ./virtualenv/ntt_itsm /opt/stackstorm/virtualenvs/ntt_itsm
chgrp -R st2packs /opt/stackstorm/packs/ntt_itsm
chgrp -R st2packs /opt/stackstorm/virtualenvs/ntt_itsm
st2 pack register /opt/stackstorm/packs/ntt_itsm